Run the qrscanner.exe
